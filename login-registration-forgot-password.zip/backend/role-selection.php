<?php

// check kung may role na napili
if ($_POST['role'] == 'student') {
    // redirect sa student page
    header("Location: student.php");
} else {
    // redirect sa faculty page
    header("Location: faculty.php");
}

/*
  Notes:
  - siguraduhin may value ang role
  - gamitin ito sa form submission
*/

?>